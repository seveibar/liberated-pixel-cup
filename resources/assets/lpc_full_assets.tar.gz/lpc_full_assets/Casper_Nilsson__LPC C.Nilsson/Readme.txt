LPC art entry by Casper Nilsson

email: casper.nilsson@gmail.com
Freenode: CasperN
OpenGameArt.org: C.Nilsson
----------------------------------

This is my first released version of two tilesets, one asian inspired, and one victorian era inspired tileset.
I have plans to expand both tilesets in the future.

If you find something that is wrong, send me an email or something and I will take a look at it and fix it when I have time.
There is allways a chance of small misstakes, and best for everyone is if the base assets gets fixed.

Use GIMP 2.8 to open the .xcf files


LICENSE
---------------------------------
The art is dual licensed under the following licenses.
*CC-BY-SA 3.0
*GNU GPL 3.0 or later
 
http://creativecommons.org/licenses/by-sa/3.0/
http://www.gnu.org/licenses/gpl-3.0.html

Please attribute creator as Casper Nilsson.
Please include a link to opengameart.org as well (preferably to the submission for this art package) if you use the art.



Some of the art in this archive are based on base assets for the LPC competition. At the time of writing
those base assets can be found at:
http://lpc.opengameart.org/static/lpc-style-guide/assets.html
