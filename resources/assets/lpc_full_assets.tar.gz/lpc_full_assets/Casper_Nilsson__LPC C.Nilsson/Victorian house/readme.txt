Some tiles in this set is for 16x grid, (the doorframe and balcony) if you need it for 32x grid,
simply select it and move it 16x horizontally to make it cover nine, 32x tiles.

Don't forget to change color on the house, it's easy to make something different with a little imagination.

The fence.png is the same tiles as in victorian house.png, but it has an extra entrance. Use it together with the gravestones found in the "Other" folder.