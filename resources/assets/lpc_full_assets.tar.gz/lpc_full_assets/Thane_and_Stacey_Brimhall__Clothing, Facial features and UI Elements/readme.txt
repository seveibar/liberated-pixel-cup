All assets made by pennomi and laetissima
Dual-Licensed under GPLv3 and CC BY-SA 3.0

Male spritesheet includes a collared shirt, vest, necktie and bowtie.
Female spritesheet includes an Irish Dancing dress and ghillies.
Dnd contains books, papers, pencils, dice soda cans and pizza boxes.
Accessories includes facial expressions, facial hair, various eyewear and other facial features.
The UI ELEMENTS directory contains an LPC-styled set of UI widgets inspired by Flare's UI elements.
